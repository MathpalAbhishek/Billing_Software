package com.capgemini.takehome.service;

import com.capgemini.takehome.Exceptions.InvalidProductCodeException;
import com.capgemini.takehome.Exceptions.InvalidQuantityException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Bill;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService{
	//DAO object creation
	private IProductDAO serviceDao=new ProductDAO();  
	//Overriden methods declarations
	@Override
	public Product getProductDetails(int productCode)throws ProductCodeNotFoundException,InvalidProductCodeException {
		if(Integer.toString(productCode).length()!=4)
			throw new InvalidProductCodeException();
		Product prod=serviceDao.getProductDetails(productCode);
		if(prod==null)
			throw new ProductCodeNotFoundException();
		return prod;
	}
	@Override
	public Bill getBill(int amount,Product prod) throws InvalidQuantityException{
		if(amount<=0)
			throw new InvalidQuantityException();
		float total=prod.getProductPrice()*amount;
		Bill bill=new Bill(prod,amount,total);
		return bill;
	}
}
