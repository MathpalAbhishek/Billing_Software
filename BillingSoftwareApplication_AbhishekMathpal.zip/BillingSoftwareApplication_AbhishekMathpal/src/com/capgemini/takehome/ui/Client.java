package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.Exceptions.InvalidProductCodeException;
import com.capgemini.takehome.Exceptions.InvalidQuantityException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.service.ProductService;

public class Client {
	static Scanner sc=new Scanner (System.in);
	//service object creation
	static ProductService prodSer=new ProductService();
	//creating method to get called in main method
	static void generateBill()
	{
		System.out.println("<<Enter Product Details>>");
		System.out.println("Enter the product code:");
		int code=sc.nextInt();
		System.out.println("Enter Quantity:");
		int quan=sc.nextInt();
		System.out.println(prodSer.getBill(quan, prodSer.getProductDetails(code)));
	}
	
	public static void main(String args[])
	{
		int choice;
		System.out.println("Welcome to Take Home Company");
		while(true)
		{
			System.out.println("********************************************");
			System.out.println("Enter 1 To Generate Bill By Entring Product Code");
			System.out.println("Enter 2 To Exit");
			choice=sc.nextInt();
			if(choice==1)
			{
				try {
				generateBill();
				}
				catch(InvalidProductCodeException e)
				{
					System.out.println(e+":Sorry! Product Code Is Not In Proper Format");
				}
				catch(InvalidQuantityException e)
				{
					System.out.println(e+":Sorry! Wrong Product Quantity");
				}
				catch(ProductCodeNotFoundException e)
				{
					System.out.println(e+":Sorry! The Product Code Is Not Available");
				}
				finally
				{
					Client.main(args);
				}
			}
			else if(choice==2)
			{
				System.out.println("Thanks for using our Services");
				System.exit(0);
			}
		}
	}
	
}
