package com.capgemini.takehome.util;

import java.util.HashMap;
import com.capgemini.takehome.bean.Product;

public class CollectionUtil {
	//HashMap object creation to store product details
	 public static HashMap<Integer, Product> products=new HashMap<>();
	 static {
		 //putting some products details
		 products.put(1001, new Product("IPhone", "Electronics", "SmartPhone", 1001, 35000.0f));
		 products.put(1002, new Product("LEDTV", "Electronics", "TV", 1002, 45000.0f));
		 products.put(1003, new Product("Teddy", "Toys", "PlayItem", 1003, 800.0f));
		 products.put(1004, new Product("Telescope", "Toys", "PlayItem", 1004, 5000.0f));
	 }

}
