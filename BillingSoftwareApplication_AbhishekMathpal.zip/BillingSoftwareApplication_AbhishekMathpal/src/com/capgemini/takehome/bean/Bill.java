package com.capgemini.takehome.bean;

public class Bill {
	Product prod;//variable declarations
	int amount;
	float totalAmount;
	//constructors
	public Bill(Product prod, int amount, float totalAmount) {
		super();
		this.prod = prod;
		this.amount = amount;
		this.totalAmount = totalAmount;
	}
	//getter setters
	public Product getProd() {
		return prod;
	}
	public void setProd(Product prod) {
		this.prod = prod;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}
	//overriden to string
	@Override
	public String toString() {
		return " [" + prod + ", Quantity=" + amount + ", totalAmount=" + totalAmount + "]";
	}
	
}
